import express from "express"
import {
  getAvailableJobs,
  startWork,
  stopWork,
  unlockJob,
} from "../controllers/workController.mjs"

const router = express.Router()

router.get("/available/:userId", getAvailableJobs)

router.post("/start", startWork)

router.post("/stop", stopWork)

router.post("/unlock", unlockJob)

export default router
