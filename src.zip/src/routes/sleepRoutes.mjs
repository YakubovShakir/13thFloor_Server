import express from "express"
import {
  startSleep,
  updateSleepProgress,
  completeSleep,
} from "../controllers/sleepController.mjs"
const router = express.Router()

router.post("/start", startSleep)
router.post("/progress", updateSleepProgress)

router.post("/complete", completeSleep)

export default router
