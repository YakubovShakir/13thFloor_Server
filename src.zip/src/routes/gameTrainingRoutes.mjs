import express from "express"
import {
  startTraining,
  updateTrainingProgress,
  completeTraining,
} from "../controllers/gameTrainingController.mjs"

const router = express.Router()

router.post("/start", startTraining)

router.post("/progress", updateTrainingProgress)

router.post("/complete", completeTraining)

export default router
