import Work from "../models/workModel.mjs"
import UserParameters from "../models/userParametersModel.mjs"
import UserWorks from "../models/userWorksModel.mjs"

export const getAvailableJobs = async (req, res) => {
  const { userId } = req.params

  if (!userId) {
    return res.status(400).send({ message: "User ID is required" })
  }

  try {
    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    const unlockedJobs = await UserWorks.find({ id: userId }).distinct(
      "work_id"
    )
    const availableJobs = await Work.find({
      respect_required: { $lte: user.respect },
      work_id: { $nin: unlockedJobs },
    }).sort({ coins_in_hour: -1 })

    res.status(200).send({ availableJobs })
  } catch (e) {
    console.error("Error fetching available jobs: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const startWork = async (req, res) => {
  const { userId, workId, duration } = req.body

  if (!userId || !workId || !duration) {
    return res
      .status(400)
      .send({ message: "userId, workId, and duration are required" })
  }

  try {
    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    const work = await Work.findOne({ work_id: workId })
    if (!work) {
      return res.status(404).send({ message: "Work not found" })
    }

    if (user.energy < work.energy_cost_in_hour * duration) {
      return res.status(400).send({ message: "Not enough energy for this job" })
    }

    // Проверяем, если пользователь уже работает на другой работе
    if (user.work_id && user.work_id !== workId) {
      return res.status(400).send({
        message:
          "User is already working on another job. Stop current job first.",
      })
    }

    const coinsEarned = work.coins_in_hour * duration

    // Обновляем ресурсы пользователя
    user.energy -= work.energy_cost_in_hour * duration
    user.mood -= work.mood_cost_in_hour * duration
    user.hungry -= work.hungry_cost_in_hour * duration
    user.coins += coinsEarned
    user.work_id = workId

    await user.save()

    res.status(200).send({
      message: "Work started successfully",
      updatedStats: {
        energy: user.energy,
        mood: user.mood,
        hungry: user.hungry,
        coins: user.coins,
      },
      coinsEarned,
    })
  } catch (e) {
    console.error("Error starting work: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const stopWork = async (req, res) => {
  const { userId } = req.body

  if (!userId) {
    return res.status(400).send({ message: "User ID is required" })
  }

  try {
    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    if (!user.work_id) {
      return res.status(400).send({ message: "User is not currently working" })
    }

    // Очищаем поле `work_id`
    user.work_id = null
    await user.save()

    res.status(200).send({ message: "Work stopped successfully" })
  } catch (e) {
    console.error("Error stopping work: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const unlockJob = async (req, res) => {
  const { userId, workId } = req.body

  if (!userId || !workId) {
    return res.status(400).send({ message: "userId and workId are required" })
  }

  try {
    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    const work = await Work.findOne({ work_id: workId })
    if (!work) {
      return res.status(404).send({ message: "Work not found" })
    }

    if (user.coins < work.coins_price) {
      return res
        .status(400)
        .send({ message: "Not enough coins to unlock this job" })
    }

    const isAlreadyUnlocked = await UserWorks.findOne({
      id: userId,
      work_id: workId,
    })
    if (isAlreadyUnlocked) {
      return res.status(400).send({ message: "Job is already unlocked" })
    }

    user.coins -= work.coins_price
    await user.save()

    const unlockedWork = new UserWorks({ id: userId, work_id: workId })
    await unlockedWork.save()

    res.status(200).send({
      message: "Job unlocked successfully",
      coins: user.coins,
    })
  } catch (e) {
    console.error("Error unlocking job: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}
