import Clan from "../models/clanModel.mjs"
import UserParameters from "../models/userParametersModel.mjs"

export const createClan = async (req, res) => {
  const { userId, clanName } = req.body

  if (!userId || !clanName) {
    return res.status(400).send({ message: "userId and clanName are required" })
  }

  try {
    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    if (user.level < 3) {
      return res
        .status(400)
        .send({ message: "You need to reach level 3 to create a clan" })
    }

    if (!user.is_influencer && user.stars < 100) {
      return res
        .status(400)
        .send({ message: "Not enough stars to create a clan" })
    }

    const existingClan = await Clan.findOne({ name: clanName })
    if (existingClan) {
      return res.status(400).send({ message: "Clan name is already taken" })
    }

    const newClan = new Clan({
      //   clan_id: , // Генерация уникального ID
      name: clanName,
      leader_id: userId,
      members: [userId],
    })

    if (!user.is_influencer) {
      user.stars -= 100
    }

    await newClan.save()
    await user.save()

    res.status(200).send({
      message: "Clan created successfully",
      clan: {
        id: newClan.clan_id,
        name: newClan.name,
        leader: newClan.leader_id,
      },
    })
  } catch (e) {
    console.error("Error creating clan: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const joinClan = async (req, res) => {
  const { userId, clanId } = req.body

  if (!userId || !clanId) {
    return res.status(400).send({ message: "userId and clanId are required" })
  }

  try {
    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    if (user.level < 3) {
      return res
        .status(400)
        .send({ message: "You need to reach level 3 to join a clan" })
    }

    const clan = await Clan.findOne({ clan_id: clanId })
    if (!clan) {
      return res.status(404).send({ message: "Clan not found" })
    }

    if (clan.members.includes(userId)) {
      return res
        .status(400)
        .send({ message: "You are already a member of this clan" })
    }

    clan.members.push(userId)
    await clan.save()

    res.status(200).send({
      message: "Successfully joined the clan",
      clan: {
        id: clan.clan_id,
        name: clan.name,
      },
    })
  } catch (e) {
    console.error("Error joining clan: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const getAvailableClans = async (req, res) => {
  try {
    const clans = await Clan.find({}).select("clan_id name leader_id members")
    if (!clans || clans.length === 0) {
      return res.status(404).send({ message: "No clans available" })
    }

    res.status(200).send({ clans })
  } catch (e) {
    console.error("Error fetching clans: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}
