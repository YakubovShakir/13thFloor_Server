import UserParameters from "../models/userParametersModel.mjs"
import UserProcess from "../models/userProcessModel.mjs"
import TrainingParameters from "../models/trainingsParameters.mjs"

export const startTraining = async (req, res) => {
  const { userId, trainingLevel } = req.body

  if (!userId || !trainingLevel) {
    return res
      .status(400)
      .send({ message: "userId and trainingLevel are required" })
  }

  try {
    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    const training = await TrainingParameters.findOne({ level: trainingLevel })
    if (!training) {
      return res.status(404).send({ message: "Training not found" })
    }

    if (user.energy < training.energy_spend) {
      return res
        .status(400)
        .send({ message: "Not enough energy to start training" })
    }

    const duration = training.duration

    const userProcess = new UserProcess({
      id: userId,
      active: true,
      type: "training",
      type_id: trainingLevel,
      duration,
    })

    await userProcess.save()

    res.status(200).send({
      message: "Training started successfully",
      training: {
        duration,
        progressBar: "decreasing",
        background: "gym",
      },
    })
  } catch (e) {
    console.error("Error starting training: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const updateTrainingProgress = async (req, res) => {
  const { userId } = req.body

  if (!userId) {
    return res.status(400).send({ message: "User ID is required" })
  }

  try {
    const userProcess = await UserProcess.findOne({
      id: userId,
      active: true,
      type: "training",
    })

    if (!userProcess) {
      return res.status(404).send({ message: "No active training found" })
    }

    userProcess.duration = Math.max(0, userProcess.duration - 30) // Уменьшаем время на 30 секунд
    await userProcess.save()

    res.status(200).send({
      message: "Training progress updated",
      remainingTime: userProcess.duration,
    })
  } catch (e) {
    console.error("Error updating training progress: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const completeTraining = async (req, res) => {
  const { userId } = req.body

  if (!userId) {
    return res.status(400).send({ message: "User ID is required" })
  }

  try {
    const userProcess = await UserProcess.findOne({
      id: userId,
      active: true,
      type: "training",
    })

    if (!userProcess) {
      return res.status(404).send({ message: "No active training found" })
    }

    if (userProcess.duration > 0) {
      return res.status(400).send({ message: "Training is not yet completed" })
    }

    const training = await TrainingParameters.findOne({
      level: userProcess.type_id,
    })
    if (!training) {
      return res.status(404).send({ message: "Training parameters not found" })
    }

    const user = await UserParameters.findOne({ id: userId })
    if (!user) {
      return res.status(404).send({ message: "User not found" })
    }

    // Обновляем характеристики пользователя
    user.energy -= training.energy_spend
    user.hungry -= training.hungry_spend
    user.mood += training.mood_profit
    await user.save()

    userProcess.active = false
    await userProcess.save()

    res.status(200).send({
      message: "Training completed successfully",
      updatedStats: {
        energy: user.energy,
        hungry: user.hungry,
        mood: user.mood,
      },
    })
  } catch (e) {
    console.error("Error completing training: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}
