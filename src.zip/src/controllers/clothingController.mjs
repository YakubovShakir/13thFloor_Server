import Clothing from "../models/clothingModel.mjs"
import UserClothing from "../models/userClothingModel.mjs"
export const getClothingCatalog = async (req, res) => {
  try {
    const clothing = await Clothing.find({}).sort({ category: 1, type: 1 })
    res.status(200).send({ clothing })
  } catch (e) {
    console.error("Error fetching clothing catalog: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const equipClothing = async (req, res) => {
  const { userId, clothingId } = req.body

  if (!userId || !clothingId) {
    return res
      .status(400)
      .send({ message: "userId and clothingId are required" })
  }

  try {
    const clothing = await Clothing.findOne({ clothing_id: clothingId })
    if (!clothing) {
      return res.status(404).send({ message: "Clothing not found" })
    }

    const userClothing =
      (await UserClothing.findOne({ user_id: userId })) ||
      new UserClothing({ user_id: userId })

    // Проверяем слот
    switch (clothing.type) {
      case "Hat":
        userClothing.equipped.hat = clothingId
        break
      case "Top":
        userClothing.equipped.top = clothingId
        break
      case "Pants":
        userClothing.equipped.pants = clothingId
        break
      case "Shoes":
        userClothing.equipped.shoes = clothingId
        break
      case "Accessory":
        if (userClothing.equipped.accessories.length >= 2) {
          return res
            .status(400)
            .send({ message: "Maximum accessories equipped" })
        }
        userClothing.equipped.accessories.push(clothingId)
        break
      default:
        return res.status(400).send({ message: "Invalid clothing type" })
    }

    await userClothing.save()

    res.status(200).send({
      message: "Clothing equipped successfully",
      equipped: userClothing.equipped,
    })
  } catch (e) {
    console.error("Error equipping clothing: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}

export const unequipClothing = async (req, res) => {
  const { userId, clothingType } = req.body

  if (!userId || !clothingType) {
    return res
      .status(400)
      .send({ message: "userId and clothingType are required" })
  }

  try {
    const userClothing = await UserClothing.findOne({ user_id: userId })
    if (!userClothing) {
      return res
        .status(404)
        .send({ message: "User clothing inventory not found" })
    }

    // Проверяем слот
    switch (clothingType) {
      case "Hat":
        userClothing.equipped.hat = null
        break
      case "Top":
        userClothing.equipped.top = null
        break
      case "Pants":
        userClothing.equipped.pants = null
        break
      case "Shoes":
        userClothing.equipped.shoes = null
        break
      case "Accessory":
        userClothing.equipped.accessories.pop() // Снимаем последний аксессуар
        break
      default:
        return res.status(400).send({ message: "Invalid clothing type" })
    }

    await userClothing.save()

    res.status(200).send({
      message: "Clothing unequipped successfully",
      equipped: userClothing.equipped,
    })
  } catch (e) {
    console.error("Error unequipping clothing: ", e)
    res.status(500).send({ error: "Internal server error" })
  }
}
